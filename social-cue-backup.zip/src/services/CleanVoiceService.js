import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

class CleanVoiceService {
  async generateResponse({
    conversationHistory = [],
    scenario = {},
    gradeLevel = '6',
    persona = 'friendly'
  }) {
    const turnCount = conversationHistory.filter(m => m.role === 'user').length;

    const gradePrompts = {
      '3': 'Speak simply and kindly, like you’re talking to a 3rd grader. Use short, friendly sentences.',
      '6': 'Use clear, supportive language. Avoid big words and use examples that feel real to a 6th grader.',
      '9': 'Use slightly more mature language. Be relatable, casual, and guide them toward thinking for themselves.'
    };
    const gradeInstruction = gradePrompts[gradeLevel] || '';

    const scenarioContext = scenario.description
      ? `The student is working on the following situation: "${scenario.description}"`
      : '';

    const personaInstructions = {
      friendly: 'You’re upbeat and supportive.',
      shy: 'You’re quiet but kind. Keep your responses short and gentle.',
      chatty: 'You love to talk. Respond with friendly enthusiasm.'
    };
    const personaInstruction = personaInstructions[persona] || '';

    let systemPrompt = '';

    if (turnCount === 0) {
      systemPrompt = `You're Cue, a warm social skills coach. Greet the student naturally and ask how they're doing. Keep it under 15 words. ${gradeInstruction}`;
    } else if (turnCount === 1) {
      systemPrompt = `You're Cue, helping with the scenario: ${scenario?.title}.
${scenarioContext}
Your goal is to:
- Acknowledge their message
- Offer 2–3 quick tips in a friendly tone
- Share a specific phrase they could say
- Describe a super short practice idea
- End with a gentle question

Be natural and casual—like a real human coach. No formatting symbols. ${gradeInstruction}`;
    } else if (turnCount >= 2 && turnCount <= 5) {
      systemPrompt = `You're a friendly student roleplaying with someone practicing social skills. React like a real peer would—short, helpful, and natural. Stay in character and keep it under 30 words. ${gradeInstruction} ${personaInstruction}`;
    } else {
      systemPrompt = `You're Cue, wrapping up. Offer warm, specific feedback on what they did well. Be encouraging and kind. Under 30 words. ${gradeInstruction}`;
    }

    const fewShotExample = turnCount === 1 ? [{
      role: 'assistant',
      content: `That’s a great start! Here are a few things to try next time:
1. Smile before you speak
2. Say their name if you know it
You could say: “Hey Jamie, cool notebook! Where’d you get it?” 

Let’s try one—what would you say if someone said “hi” in the hallway?`
    }] : [];

    const messages = [
      { role: 'system', content: systemPrompt },
      ...fewShotExample,
      ...conversationHistory
        .filter(msg => (msg?.text || msg?.content || '').trim())
        .map(msg => ({
          role: msg.role === 'user' ? 'user' : 'assistant',
          content: (msg?.text || msg?.content || '').trim()
        }))
    ];

    try {
      const response = await openai.chat.completions.create({
        model: 'gpt-4-1106-preview',
        messages,
        temperature: 0.8,
        max_tokens: 120
      });

      let aiResponse = response.choices[0]?.message?.content?.trim() || '';

      const wrapUps = [
        "You stayed confident—amazing job!",
        "Nice work using friendly words!",
        "I liked how clearly you spoke.",
        "Your energy felt really welcoming!",
        "You’re improving every round!"
      ];

      if (turnCount >= 6) {
        aiResponse += ` ${wrapUps[Math.floor(Math.random() * wrapUps.length)]}`;
      }

      return {
        aiResponse,
        shouldContinue: turnCount < 7,
        phase: turnCount < 2 ? 'intro' : turnCount < 6 ? 'practice' : 'feedback'
      };
    } catch (error) {
      console.error('❌ Error:', error);
      throw error;
    }
  }
}

export default new CleanVoiceService();